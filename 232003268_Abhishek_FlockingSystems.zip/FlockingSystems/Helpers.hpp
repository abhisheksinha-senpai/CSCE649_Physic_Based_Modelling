#pragma once
#include "Definitions.hpp"

GLFWwindow* init_openGL(unsigned int& shaderPgm);
